package com.whimsicalhubris.magicschool;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.maps.tiled.renderers.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.maps.*;
import com.badlogic.gdx.maps.objects.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.badlogic.gdx.utils.viewport.*;
import com.badlogic.gdx.scenes.scene2d.actions.*;
import java.util.*;

public class mapScreen implements Screen
{
	Game theGame;
	public mapScreen(Game gameLoad)
	{
		this.theGame = gameLoad;
	} // end constructor

	SpriteBatch menuBatch;
	Stage menuStage;
	Skin theSkin;
	//TiledMapRenderer tileRend;
	OrthogonalTiledMapRendererWithSprites tileRend;
	OrthographicCamera orthoCam;
	float width, height;
	Vector3 touchCoords;
	Vector2 startPos;
	Vector2 safePos;
	MapObjects collObjects;
	Rectangle tempRec; 
	Rectangle tempPortRec;
	String props;
	String wallProps;
	String portalProp;
	String dialogProp;
	Label diog;
	Window diogWindow;
	Texture diogBack;
	TextureRegionDrawable diogDrawable;
	boolean diogOnScreen = false;
	RectangleMapObject diogHolder;
	TextButton contButt;
	String diogNum;
	int diogPlaceHold = 0; 
	int diogMax = 1;
	ArrayList diogSpeaker;
	ArrayList diogContent;
	 
	
	Viewport viewport;
	

	// Assets
	
	Texture backTex; 
	
	// declare maps here
	TiledMap entrance;
	TiledMap entranceHut;
	
	
	Texture guy;
	Sprite guySprite;

	@Override
	public void show()
	{
		float width = Gdx.graphics.getWidth()/4;
		float height = Gdx.graphics.getHeight()/4;
		// Drawing requirements
		orthoCam = new OrthographicCamera();
		orthoCam.setToOrtho(false, width, height);
		orthoCam.update();
		
		// duog initiate
		diogSpeaker = new ArrayList();
		diogContent = new ArrayList();
		
		//------++
		// load maps here
		entrance = new TmxMapLoader().load("entrance.tmx");
		entranceHut = new TmxMapLoader().load("entranceHut.tmx");
		//_-------==
		
		// firat map
		// change to loaded later
		
		tileRend = new OrthogonalTiledMapRendererWithSprites(entrance, 1);
		collObjects = entrance.getLayers().get("collision").getObjects();
		
		
		
		
		// collisions
		//int objectLayerId = 3;
		//TiledMapTileLayer collisionObjectLayer = (TiledMapTileLayer)map.getLayers().get("collision");
		//objects = collisionObjectLayer.getObjects();
		
		
		//guyPos = new Vector2(256, 512);
		//safePos = new Vector2(guyPos);
		touchCoords = new Vector3(256,256, 0);
		
		menuBatch = new SpriteBatch();
		menuBatch.setProjectionMatrix(orthoCam.combined);
		//viewport = new FitViewport(width, height, orthoCam);
		menuStage = new Stage();
		theSkin = new Skin(Gdx.files.internal("skin/craftacular-ui.json"));
		diog = new Label("", theSkin);

		diogWindow = new Window("", theSkin);
		diogWindow.setPosition(width/2, height/2);
		contButt = new TextButton("Okay", theSkin);
		contButt.setSize(200, 100);
		contButt.setPosition(Gdx.graphics.getWidth() -contButt.getWidth(), height/3);
		//menuStage.addActor(contButt);
		
		contButt.addListener(new ChangeListener() 
		{
			@Override
			public void changed (ChangeEvent event, Actor actor) 
			{
				if(diogOnScreen)
				{
					if(diogPlaceHold == diogMax)
					{
						// on last dialog
						contButt.remove();
						diogWindow.remove();
						diogOnScreen = false;
						diogMax =0;
						diogPlaceHold = 0;
					} // end if
					else
					{
						diogPlaceHold += 1;
					}
				}// end if onscreen
			}
		});
		Gdx.input.setInputProcessor(menuStage);
		// loading assets
		//backTex = new Texture(Gdx.files.internal("shoe.jpg"));
		guy = new Texture(Gdx.files.internal("guy.png"));
        guySprite = new Sprite(guy);
		guySprite.setSize(32, 32);
		guySprite.setPosition(256, 500);
		tileRend.addSprite(guySprite);
		
		diogBack = new Texture(Gdx.files.internal("diagBack.png"));
		diogDrawable = new TextureRegionDrawable(diogBack);
		diogHolder = new RectangleMapObject();
		
		// inital set of map
		setMap("entrance");
		
	} // end show

	@Override
	public void render(float p1)
	{
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
	
		orthoCam.update();
		tileRend.setView(orthoCam);
		tileRend.render();
		
		menuBatch.begin();
		menuBatch.setProjectionMatrix(orthoCam.combined);
		// Start drawing
		// backGround
		//menuBatch.draw(guy, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		// end drawing
		//guySprite.draw(menuBatch);
		menuBatch.end();
		
		

		// stage
		menuStage.draw();
		menuStage.act();
	
		
		// movement
		if(Gdx.input.isTouched())
		{
			if(!diogOnScreen)
			{
				touchCoords.set(Gdx.input.getX(), Gdx.input.getY(), 0);
				orthoCam.unproject(touchCoords);
				//guyPos.set(guySprite.getX(), guySprite.getY());
				if(touchCoords.x > guySprite.getX())
				{
					if(safeToMoveRight())
					{
						//guySprite.translateX(100);//*Gdx.graphics.getDeltaTime());
						guySprite.setPosition(guySprite.getX() + 2f,  guySprite.getY());
					}
				} // end right
				if(touchCoords.x < guySprite.getX())
				{
					if(safeToMoveLeft())
					{
						//guySprite.translateX(100);//* Gdx.graphics.getDeltaTime());
						guySprite.setPosition(guySprite.getX() - 2f,  guySprite.getY());
					}
				} // end left
				if(touchCoords.y < guySprite.getY())
				{
					if(safeToMoveDown())
					{
						guySprite.setPosition(guySprite.getX(), guySprite.getY() - 2f);//(0.1f *Gdx.graphics.getDeltaTime()));
					}
				} // end up
				if(touchCoords.y > guySprite.getY())
				{
					if(safeToMoveUp())
					{
						guySprite.setPosition(guySprite.getX(), guySprite.getY() + 2f); // (0.1f *Gdx.graphics.getDeltaTime()));
					}
				} // end down
			} // end if not diog
			if(diogOnScreen)
			{
				//diogWindow.setPosition(width/2, height/2);
				handleDialog(diogHolder);
				
			}
		} // end if touched
		//orthoCam.position.x = guyPos.x;
		//orthoCam.position.y = guyPos.y;
		orthoCam.update();
		//guyPos.set(guySprite.getX(), guySprite.getY());
		orthoCam.position.set(guySprite.getX(), guySprite.getY(), 0);
		
		
		
		
	} // end render
	
	void setMap(String map)
	{
		switch(map)
		{
			case "entrance":
				tileRend.setMap(entrance);
				collObjects = entrance.getLayers().get("collision").getObjects();
			
				break;
		case "entranceHut":
				tileRend.setMap(entranceHut);
				collObjects = entranceHut.getLayers().get("collision").getObjects();
				
				break;
		} // end switch
		
		for (RectangleMapObject rectangleObject : collObjects.getByType(RectangleMapObject.class)) 
		{
			if(rectangleObject.getProperties() != null)
			{
				props = rectangleObject.getProperties().get("startLoc", String.class);
				if(props != null)
				{
					if(props.equals("here"))
					{
						Vector2 spot = new Vector2();
						rectangleObject.getRectangle().getPosition(spot);
						guySprite.setPosition(spot.x, spot.y);
						
					}// end if
				}// emd if
			}// end if
		}// emd for
		
	}// end setmap
	
	void handleDialog(RectangleMapObject rect)
	{
		if(rect.getProperties() != null)
		{
			 dialogProp = rect.getProperties().get("dialog", String.class);
			 diogNum = rect.getProperties().get("diogNum", String.class);
			 if(dialogProp != null)
			 {
				 if(!diogOnScreen)
				 {
					 // firther dialog?
					 if(diogNum != null)
					 {
						// diogMax = Integer.parseInt(diogNum);
					 }
					diogHolder = rect;
					diogPlaceHold = 1;
				 	diogOnScreen = true;
					parseString(dialogProp);
					//diog.setText(dialogProp);
					// diog.setPosition(guySprite.getX(), guySprite.getY());
					//diogWindow.add(diog).pad(100);
					//diogWindow.setBackground(diogDrawable);
					//diogWindow.pack();
					//diogWindow.setPosition((Gdx.graphics.getWidth()/2)-(diogWindow.getWidth()/2), (Gdx.graphics.getHeight()/2)-(diogWindow.getHeight()/2));
				 	menuStage.addActor(diogWindow);
					menuStage.addActor(contButt);
					// diog.getStyle().background
				} // end if on screen
				if(diogOnScreen)
				{
					//diog.setText(diogContent.get(diogPlaceHold));
					//diogWindow.add(diog).pad(100);
					//parseString(dialogProp);
				
				} // 
			 }// end if not null
		}
	} // end handleDialog
	
	void parseString (String rawDialog)
	{
		// read through dialog string, break it into
		// plain dialog, me, alphonse, Lucille
		// count total strings, set max diag
		Scanner scan = new Scanner(rawDialog);
		scan.useDelimiter("/");
		while(scan.hasNext())
		{
			//diogContent.add(scan.next());
			diogMax += 1;
			if(scan.next() == "$")
			{
				break;
			}
		} // end while
		scan.close();
	} // end parseString
	
	boolean safeToMoveLeft()
	{
		Rectangle tempy = guySprite.getBoundingRectangle();
		tempy.x  -= 2;
		//guySprite.setPosition(guySprite.getX()-2, guySprite.getY());
		
		for (RectangleMapObject rectangleObject : collObjects.getByType(RectangleMapObject.class)) 
		{
			if(rectangleObject.getProperties() != null)
			{
				Rectangle rec = rectangleObject.getRectangle();
				if(Intersector.overlaps(rec, tempy))
				{
					dialogProp = rectangleObject.getProperties().get("dialog", String.class);
					if(dialogProp != null)
					{
						handleDialog(rectangleObject);
						//diogOnScreen = true;
						//diogHolder = rectangleObject;
						//guySprite.setPosition(guySprite.getX()+2, guySprite.getY());
						return false;
					} // end if dialog
					portalProp = rectangleObject.getProperties().get("portal", String.class);
					if(portalProp != null)
					{
						setMap(portalProp);
					} // end if portal
					wallProps = rectangleObject.getProperties().get("wall", String.class);
					if(wallProps != null)
					{
						if(wallProps.equals("wall"))
						{
							guySprite.setPosition(guySprite.getX()+2, guySprite.getY());
							return false;
						}// end if
					}// end if wallprops null
				} // end if interawct	
			}// end if
		}// end for
		//guySprite.setPosition(guySprite.getX()+2, guySprite.getY());
		
		return true;
	}
	
	boolean safeToMoveRight()
	{
		
		guySprite.setPosition(guySprite.getX()+2, guySprite.getY());
		
		for (RectangleMapObject rectangleObject : collObjects.getByType(RectangleMapObject.class)) 
		{
			if(rectangleObject.getProperties() != null)
			{
				
				if(rectangleObject.getProperties() != null)
				{
					Rectangle rec = rectangleObject.getRectangle();
					if(Intersector.overlaps(rec, guySprite.getBoundingRectangle()))
					{
						dialogProp = rectangleObject.getProperties().get("dialog", String.class);
						if(dialogProp != null)
						{
							handleDialog(rectangleObject);
							guySprite.setPosition(guySprite.getX()-2, guySprite.getY());
							return false;
						} // end if dialog
						portalProp = rectangleObject.getProperties().get("portal", String.class);
						if(portalProp != null)
						{
							setMap(portalProp);
						} // end if portal
						wallProps = rectangleObject.getProperties().get("wall", String.class);
						if(wallProps != null)
						{
							if(wallProps.equals("wall"))
							{
								guySprite.setPosition(guySprite.getX()-2, guySprite.getY());
								return false;
							}// end if
						}// end if wallprops null
					} // end if interawct	
				}// end if
			}// end if
			
		}// end for
		guySprite.setPosition(guySprite.getX()-2, guySprite.getY());
		
		return true;
	}
	
	boolean safeToMoveUp()
	{
		
		guySprite.setPosition(guySprite.getX(), guySprite.getY()+2 );
		
		for (RectangleMapObject rectangleObject : collObjects.getByType(RectangleMapObject.class)) 
		{
			
			if(rectangleObject.getProperties() != null)
			{
				Rectangle rec = rectangleObject.getRectangle();
				if(Intersector.overlaps(rec, guySprite.getBoundingRectangle()))
				{
					dialogProp = rectangleObject.getProperties().get("dialog", String.class);
					if(dialogProp != null)
					{
						handleDialog(rectangleObject);
						guySprite.setPosition(guySprite.getX(), guySprite.getY()-2);
						return false;
					} // end if dialog
					portalProp = rectangleObject.getProperties().get("portal", String.class);
					 if(portalProp != null)
					{
						setMap(portalProp);
					} // end if portal
					wallProps = rectangleObject.getProperties().get("wall", String.class);
					if(wallProps != null)
					{
						if(wallProps.equals("wall"))
						{
							guySprite.setPosition(guySprite.getX(), guySprite.getY()-2);
							return false;
						}// end if
					}// end if wallprops null
				} // end if interawct	
			}// end if
			
		}// end for
		guySprite.setPosition(guySprite.getX(), guySprite.getY()-2);
		
		return true;
	}
	
	boolean safeToMoveDown()
	{
		
		guySprite.setPosition(guySprite.getX(), guySprite.getY()-2);
		
		for (RectangleMapObject rectangleObject : collObjects.getByType(RectangleMapObject.class)) 
		{
			
			if(rectangleObject.getProperties() != null)
			{
				Rectangle rec = rectangleObject.getRectangle();
				if(Intersector.overlaps(rec, guySprite.getBoundingRectangle()))
				{
					dialogProp = rectangleObject.getProperties().get("dialog", String.class);
					if(dialogProp != null)
					{
						handleDialog(rectangleObject);
						guySprite.setPosition(guySprite.getX(), guySprite.getY()+2);
						return false;
					} // end if dialog
					portalProp = rectangleObject.getProperties().get("portal", String.class);
					if(portalProp != null)
					{
						setMap(portalProp);
					} // end if portal
					wallProps = rectangleObject.getProperties().get("wall", String.class);
					if(wallProps != null)
					{
						if(wallProps.equals("wall"))
						{
							guySprite.setPosition(guySprite.getX(), guySprite.getY()+2);
							return false;
						}// end if
					}// end if wallprops null
				} // end if interawct	
			}// end if
		}// end for
		guySprite.setPosition(guySprite.getX(), guySprite.getY()+2);
		
		return true;
	}
	
	@Override
	public void pause()
	{
		// TODO: Implement this method
	}  // end pause

	@Override
	public void resume()
	{
		// TODO: Implement this method
	} // emd resume

	@Override
	public void hide()
	{
		// TODO: Implement this method
	} // end hide

	@Override
	public void resize(int p1, int p2)
	{
		// TODO: Implement this method
	} // end resize

	@Override
	public void dispose()
	{
		// TODO: Implement this method
	} // end dispose
}
