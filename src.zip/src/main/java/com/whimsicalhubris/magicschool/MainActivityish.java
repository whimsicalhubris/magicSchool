package com.whimsicalhubris.magicschool;

import android.app.*;
import android.os.*;
import com.badlogic.gdx.backends.android.*;
import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import android.view.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;

public class MainActivityish extends AndroidApplication
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		AndroidApplicationConfiguration cfg = new AndroidApplicationConfiguration();
      //  initialize(new splash(this), cfg);
	  initialize(new mainGame(),cfg);
    } // end create
	
	
}
