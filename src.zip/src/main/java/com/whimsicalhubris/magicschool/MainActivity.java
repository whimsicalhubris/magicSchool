package com.whimsicalhubris.magicschool;

import android.app.*;
import android.os.*;
import com.badlogic.gdx.backends.android.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;

public class MainActivity extends AndroidApplication
{
    @Override
 //   protected void onCreate(Bundle savedInstanceState)
 //   {
    //    super.onCreate(savedInstanceState);
    //    setContentView(R.layout.main);
		
	protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		AndroidApplicationConfiguration cfg = new AndroidApplicationConfiguration();
		//  initialize(new splash(this), cfg);
		initialize(new mainGame(),cfg);
    } // end create
    
}
