package com.whimsicalhubris.magicschool;
import com.badlogic.gdx.*;

public class mainGame extends Game
{
	private Game game;
	public mainGame()
	{
		game = this;
	} // end mainGame
	
	@Override
	public void create()
	{
		// TODO: Implement this method
		game.setScreen(new splash(game));
	} // end create
} // end game
