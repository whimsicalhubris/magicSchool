package com.whimsicalhubris.magicschool;

public class assetManager
{
	
	
} // end assetManagwr
