package com.whimsicalhubris.magicschool;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*; 

public class menuScreen implements Screen
{
	Game theGame;
	public menuScreen(Game gameLoad)
	{
		this.theGame = gameLoad;
	} // end constructor
	
	SpriteBatch menuBatch;
	Stage menuStage;
	Skin theSkin;
	
	// Assets
	Texture backTex; 
	
	@Override
	public void show()
	{
		// Drawing requirements
		menuBatch = new SpriteBatch();
		menuStage = new Stage();
		theSkin = new Skin(Gdx.files.internal("skin/craftacular-ui.json"));
		// loading assets
		backTex = new Texture(Gdx.files.internal("shoe.jpg"));
		
	} // end show

	@Override
	public void render(float p1)
	{
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		menuBatch.begin();
		// Start drawing
		// backGround
		menuBatch.draw(backTex, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		// end drawing
		menuBatch.end();

		// stage
		menuStage.draw();
		menuStage.act();
	} // end render

	@Override
	public void pause()
	{
		// TODO: Implement this method
	}  // end pause

	@Override
	public void resume()
	{
		// TODO: Implement this method
	} // emd resume

	@Override
	public void hide()
	{
		// TODO: Implement this method
	} // end hide

	@Override
	public void resize(int p1, int p2)
	{
		// TODO: Implement this method
	} // end resize

	@Override
	public void dispose()
	{
		// TODO: Implement this method
	} // end dispose
	
} // end menuscreen
