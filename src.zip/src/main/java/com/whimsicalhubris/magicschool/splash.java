package com.whimsicalhubris.magicschool;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.assets.*;
import com.badlogic.gdx.audio.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.math.*;

public class splash implements Screen
{
	private Game theGame;
	public splash(Game loadedGame)
	{
		theGame = loadedGame;
	} // end constructor

	SpriteBatch splashBatch;
	Texture splashTex;
	long[] timer = new long[2];
	//String startMap ="introLevel";
	//String startMap = "blooshOne";
	//String startMap = "ship";
	//String startMap = "greebleOne";
	//String startChar = "IO23";
//	String startChar = "POD24";


	@Override
	public void show()
	{
		// SplashScreen Graphics
		splashBatch = new SpriteBatch();
		splashTex = new Texture(Gdx.files.internal("splash.png"));

		timer[0] = TimeUtils.millis();

		// Assetmanager loading for main game file

		/*
		// IO23
		theGame.assetMan.load("characters/IO23Stand1.png", Texture.class);
		theGame.assetMan.load("characters/IO23Stand2.png", Texture.class);
		theGame.assetMan.load("characters/IO23Jump1.png", Texture.class);
		theGame.assetMan.load("characters/IO23Jump2.png", Texture.class);
		theGame.assetMan.load("characters/IO23Drive1.png", Texture.class);
		theGame.assetMan.load("characters/IO23Drive2.png", Texture.class);
		theGame.assetMan.load("characters/IO23Drive3.png", Texture.class);
		theGame.assetMan.load("characters/IO23Attack1.png", Texture.class);
		theGame.assetMan.load("characters/IO23Attack2.png", Texture.class);
		theGame.assetMan.load("characters/IO23Attack3.png", Texture.class);
		theGame.assetMan.load("characters/blueBlast1.png", Texture.class);
		theGame.assetMan.load("characters/blueBlast2.png", Texture.class);
		theGame.assetMan.load("characters/IO23Card.png", Texture.class);

		//POD24
		theGame.assetMan.load("characters/POD24Stand1.png", Texture.class);
		theGame.assetMan.load("characters/POD24Stand2.png", Texture.class);
		theGame.assetMan.load("characters/POD24Stand3.png", Texture.class);
		theGame.assetMan.load("characters/POD24Stand4.png", Texture.class);
		theGame.assetMan.load("characters/POD24Drive1.png", Texture.class);
		theGame.assetMan.load("characters/POD24Drive2.png", Texture.class);
		theGame.assetMan.load("characters/POD24Drive3.png", Texture.class);
		theGame.assetMan.load("characters/POD24Jump1.png", Texture.class);
		theGame.assetMan.load("characters/POD24Jump2.png", Texture.class);

		// hearts
		theGame.assetMan.load("characters/heart1.png", Texture.class);
		theGame.assetMan.load("characters/heart2.png", Texture.class);

		// heartPick
		theGame.assetMan.load("characters/heartPickFrame1.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame2.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame3.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame4.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame5.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame6.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame7.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame8.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame9.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame10.png", Texture.class);
		theGame.assetMan.load("characters/heartPickFrame11.png", Texture.class);

		// elevator
		theGame.assetMan.load("characters/elevator1.png", Texture.class);
		theGame.assetMan.load("characters/elevator2.png", Texture.class);
		theGame.assetMan.load("characters/elevator3.png", Texture.class);
		theGame.assetMan.load("characters/elevator4.png", Texture.class);
		theGame.assetMan.load("characters/elevator5.png", Texture.class);

		// info
		theGame.assetMan.load("characters/info1.png", Texture.class);
		theGame.assetMan.load("characters/info2.png", Texture.class);
		theGame.assetMan.load("characters/info3.png", Texture.class);
		theGame.assetMan.load("characters/info4.png", Texture.class);
		theGame.assetMan.load("characters/info5.png", Texture.class);
		theGame.assetMan.load("characters/info6.png", Texture.class);
		theGame.assetMan.load("characters/info7.png", Texture.class);
		theGame.assetMan.load("characters/info8.png", Texture.class);

		// ship things
		theGame.assetMan.load("maps/coreNoPower.png", Texture.class);
		theGame.assetMan.load("maps/corePower1.png", Texture.class);
		theGame.assetMan.load("maps/corePower2.png", Texture.class);
		theGame.assetMan.load("maps/corePower3.png", Texture.class);
		theGame.assetMan.load("maps/corePower4.png", Texture.class);
		theGame.assetMan.load("maps/computer.png", Texture.class);

		// cyrstals
		theGame.assetMan.load("characters/cyrstalFrame1.png", Texture.class);
		theGame.assetMan.load("characters/cyrstalFrame2.png", Texture.class);

		// idonic
		theGame.assetMan.load("baddies/idonicFrame1.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame2.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame3.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame4.png", Texture.class);

		// cube
		theGame.assetMan.load("baddies/cubeFrame1.png", Texture.class);
		theGame.assetMan.load("baddies/cubeFrame2.png", Texture.class);
		theGame.assetMan.load("baddies/cubeFrame3.png", Texture.class);
		theGame.assetMan.load("baddies/cubeFrame4.png", Texture.class);

		// armbear
		theGame.assetMan.load("baddies/armBearFrame1.png", Texture.class);
		theGame.assetMan.load("baddies/armBearFrame2.png", Texture.class);
		theGame.assetMan.load("baddies/armBearFrame3.png", Texture.class);
		theGame.assetMan.load("baddies/armBearFrame4.png", Texture.class);

		// stomper
		theGame.assetMan.load("baddies/stomperFrame1.png", Texture.class);
		theGame.assetMan.load("baddies/stomperFrame2.png", Texture.class);
		theGame.assetMan.load("baddies/stomperFrame3.png", Texture.class);
		theGame.assetMan.load("baddies/stomperFrame4.png", Texture.class);

		// baddie five
		theGame.assetMan.load("baddies/idonicFrame1.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame2.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame3.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame4.png", Texture.class);

		// baddie six
		theGame.assetMan.load("baddies/idonicFrame1.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame2.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame3.png", Texture.class);
		theGame.assetMan.load("baddies/idonicFrame4.png", Texture.class);

		//zap
		theGame.assetMan.load("baddies/zap1.png", Texture.class);
		theGame.assetMan.load("baddies/zap2.png", Texture.class);
		theGame.assetMan.load("baddies/zap3.png", Texture.class);
		theGame.assetMan.load("baddies/zap4.png", Texture.class);

		// laser Grid
		theGame.assetMan.load("baddies/laser1.png", Texture.class);
		theGame.assetMan.load("baddies/laser2.png", Texture.class);
		theGame.assetMan.load("baddies/laser3.png", Texture.class);
		theGame.assetMan.load("baddies/laser4.png", Texture.class);

		//Boss Bar
		theGame.assetMan.load("baddies/baddieBar.png", Texture.class);

		// skin
		theGame.assetMan.load("skin/uiskin.json", Skin.class);

		// levels
		theGame.assetMan.setLoader(TiledMap.class, new TmxMapLoader());
		theGame.assetMan.load("maps/introLevel.tmx", TiledMap.class);
		theGame.assetMan.setLoader(TiledMap.class, new TmxMapLoader());
		theGame.assetMan.load("maps/shipBase.tmx", TiledMap.class);

		// Worlds info

		// blarg
		theGame.assetMan.load("maps/blarg.png", Texture.class);
		theGame.assetMan.load("maps/blargOne.png", Texture.class);
		theGame.assetMan.load("maps/blargTwo.png", Texture.class);
		theGame.assetMan.load("maps/blargThree.png", Texture.class);
		theGame.assetMan.load("maps/blargFour.png", Texture.class);
		theGame.assetMan.setLoader(TiledMap.class, new TmxMapLoader());
		theGame.assetMan.load("maps/blargOne.tmx", TiledMap.class);
		theGame.assetMan.setLoader(TiledMap.class, new TmxMapLoader());
		theGame.assetMan.load("maps/blargTwo.tmx", TiledMap.class);
		theGame.assetMan.setLoader(TiledMap.class, new TmxMapLoader());
		theGame.assetMan.load("maps/blargThree.tmx", TiledMap.class);
		theGame.assetMan.setLoader(TiledMap.class, new TmxMapLoader());
		theGame.assetMan.load("maps/blargFour.tmx", TiledMap.class);
		theGame.assetMan.load("backgrounds/blargOne.png", Texture.class);
		theGame.assetMan.load("backgrounds/blargTwo.png", Texture.class);
		theGame.assetMan.load("backgrounds/blargThree.png", Texture.class);
		theGame.assetMan.load("backgrounds/blargFour.png", Texture.class);

		// bloosh
		theGame.assetMan.load("maps/bloosh.png", Texture.class);
		theGame.assetMan.load("maps/blooshOne.png", Texture.class);
		theGame.assetMan.load("maps/blooshTwo.png", Texture.class);
		theGame.assetMan.load("maps/blooshThree.png", Texture.class);
		theGame.assetMan.load("maps/blooshFour.png", Texture.class);
		theGame.assetMan.load("backgrounds/blooshOne.png", Texture.class);
		theGame.assetMan.load("backgrounds/blooshTwo.png", Texture.class);
		theGame.assetMan.load("backgrounds/blooshThree.png", Texture.class);
		theGame.assetMan.load("backgrounds/blooshFour.png", Texture.class);

		// greeble
		theGame.assetMan.load("backgrounds/greebleOne.png", Texture.class);


		// backgrounds
		theGame.assetMan.load("backgrounds/spaceBack1.png", Texture.class);
		theGame.assetMan.load("backgrounds/introLevel.png", Texture.class);
		theGame.assetMan.load("backgrounds/shipBase.png", Texture.class);

		//Sound
		theGame.assetMan.load("sound/laser.mp3", Music.class);
		theGame.assetMan.load("sound/laser2.mp3", Music.class);
		theGame.assetMan.load("sound/laser3.mp3", Music.class);
		theGame.assetMan.load("sound/laser4.mp3", Music.class);
		theGame.assetMan.load("sound/laser5.mp3", Music.class);
		theGame.assetMan.load("sound/laser6.mp3", Music.class);
		theGame.assetMan.load("sound/laser7.mp3", Music.class);
		theGame.assetMan.load("sound/boing.mp3", Music.class);
		theGame.assetMan.load("sound/IO23Buzz.mp3", Music.class);
	*/
	} // end show

	//@Override
	public void render(float a)
	{
		//super.render();
		
		// clear screen, background colour
		Gdx.gl.glClearColor(34, 134, 216, 1);
	    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		timer[1] = TimeUtils.timeSinceMillis(timer[0]);

		// if it returns true, switch screens
		//if(theGame.assetMan.update())
		{
			if(timer[1] > 1000)
			{
				//splashBatch.end();
				//splashBatch.dispose();
				//theGame.setScreen(new minerHome(theGame));
				//theGame.setScreen(new shipBase(theGame, startChar));
				//this.setScreen(new minerHome(theGame));
			}

		} // end of if assetMan

		// start drawing
		// dont forget to dispose of the batch when calling the new screen
		splashBatch.begin();

		splashBatch.draw(splashTex, 0,0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

		splashBatch.end();
		
		// if it returns true, switch screens
		//if(theGame.assetMan.update())
		{
			if(timer[1] > 1000)
			{
				//splashBatch.end();
				//splashBatch.dispose();
				theGame.setScreen(new mapScreen(theGame));
				//setScreen(new mining(this));
				//super.render();
			}

		} // end of if assetMan
	} // end render

	@Override
	public void resize(int p1, int p2)
	{
		// TODO: Implement this method
	}

	@Override
	public void hide()
	{
		// TODO: Implement this method
	}
	// end resize

	@Override
	public void pause()
	{
		// TODO: Implement this method
	}

	@Override
	public void resume()
	{
		// TODO: Implement this method
	}

	@Override
	public void dispose()
	{

	}



} // end splashScreen
